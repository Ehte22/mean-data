import { NgModule } from "@angular/core";
import { CreateTaskComponent } from "./create-task/create-task.component";
import { TaskDetailsComponent } from "./task-details/task-details.component";
import { DashboardComponent } from "./dashboard.component";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { SharedModule } from "../shared.module";
import { OverviewComponent } from './overview/overview.component';
import { RouterModule } from "@angular/router";
import { StatsComponent } from './stats/stats.component';

@NgModule({
    declarations: [
        DashboardComponent,
        CreateTaskComponent,
        TaskDetailsComponent,
        OverviewComponent,
        StatsComponent,
    ],
    exports: [
        DashboardComponent,
        CreateTaskComponent,
        TaskDetailsComponent,
        SharedModule
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule
    ]

})
export class DashBoardModule {

}